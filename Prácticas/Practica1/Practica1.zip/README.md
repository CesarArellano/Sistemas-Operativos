# Práctica 1

En esta práctica pretende explicar el funcionamiento de los hilos y los semáforos para optimizar tiempos de ejecución de tareas específicas (haciendo uso del paradigma de multiprogramación).

### Pre-requisitos 📋

Tener instalado gcc en nuestro sistema Linux.

### Ejecución ⚙️

_Para poder compilar y ejecutar del programa es suficiente con ejecutar los siguientes comandos_

gcc practicaUno.c -o practicaUno -lpthread

./practicaUno

## Autores ✒️

* **César Arellano** - *Desarrollo* - (https://github.com/CesarArellano)
